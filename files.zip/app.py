"""
app.py - Главный сервер Кибернадзор Веб Приложения
Запуск: python app.py
Открыть: http://localhost:5000  или  http://[IP компьютера]:5000
"""

import os
import re
import csv
import json
import time
import threading
import traceback
import requests
import urllib.parse
from pathlib import Path
from datetime import datetime
from queue import Queue

from flask import Flask, render_template, jsonify, request, send_file
import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# ════════════════════════════════════════════════════════════════
app = Flask(__name__)

# ════════════════════════════════════════════════════════════════
# НАСТРОЙКИ
# ════════════════════════════════════════════════════════════════
CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    "screens_dir":        r"C:\Users\Пользователь\Desktop\knadzor_bot\screens",
    "data_dir":           r"C:\Users\Пользователь\Desktop\knadzor_bot\Links",
    "auth_file":          r"C:\Users\Пользователь\Desktop\knadzor_bot\auth.json",
    "google_api_key":     "",
    "knadzor_url":        "https://knadzor.kz/#/links",
    "default_violation":  "Интернет-мошенничество (Фишинговый сайт)",
    "default_object_type":"Интернет-ресурс",
    "default_resource_type": "Тематические сайты",
    "default_language":   "Русский",
    "default_group":      "оранжевый",
    "default_reason":     "Фишинговый ресурс",
    "workers":            2,
}


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, encoding="utf-8") as f:
            cfg = json.load(f)
        # Добавляем новые ключи если их нет
        for k, v in DEFAULT_CONFIG.items():
            cfg.setdefault(k, v)
        return cfg
    return DEFAULT_CONFIG.copy()


def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ════════════════════════════════════════════════════════════════
# СОСТОЯНИЕ ПРИЛОЖЕНИЯ
# ════════════════════════════════════════════════════════════════
state = {
    "running":    False,
    "task":       None,      # "fetch" | "screenshot" | "upload" | "auto"
    "total":      0,
    "done":       0,
    "ok":         0,
    "err":        0,
    "skip":       0,
    "log":        [],        # список строк лога
    "links":      [],        # загруженные ссылки
    "csv_path":   None,
    "stats": {
        "total_links":   0,
        "total_screens": 0,
        "total_uploaded": 0,
        "total_errors":  0,
    }
}
state_lock = threading.Lock()


def log(msg, level="info"):
    ts = datetime.now().strftime("%H:%M:%S")
    entry = {"ts": ts, "msg": msg, "level": level}
    with state_lock:
        state["log"].append(entry)
        if len(state["log"]) > 500:
            state["log"] = state["log"][-500:]
    print(f"[{ts}] {msg}")


def set_progress(done, total, ok=None, err=None, skip=None):
    with state_lock:
        state["done"]  = done
        state["total"] = total
        if ok   is not None: state["ok"]   = ok
        if err  is not None: state["err"]  = err
        if skip is not None: state["skip"] = skip


# ════════════════════════════════════════════════════════════════
# FLASK РОУТЫ
# ════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    cfg = load_config()
    screens_dir = Path(cfg["screens_dir"])
    screens_count = len(list(screens_dir.glob("*.png"))) if screens_dir.exists() else 0

    with state_lock:
        return jsonify({
            "running":  state["running"],
            "task":     state["task"],
            "total":    state["total"],
            "done":     state["done"],
            "ok":       state["ok"],
            "err":      state["err"],
            "skip":     state["skip"],
            "links_count":   len(state["links"]),
            "screens_count": screens_count,
            "log":      state["log"][-50:],
            "stats":    state["stats"],
        })


@app.route("/api/config", methods=["GET"])
def api_config_get():
    return jsonify(load_config())


@app.route("/api/config", methods=["POST"])
def api_config_set():
    cfg = load_config()
    data = request.json
    cfg.update(data)
    save_config(cfg)
    return jsonify({"ok": True})


@app.route("/api/fetch_openphish", methods=["POST"])
def api_fetch():
    if state["running"]:
        return jsonify({"ok": False, "error": "Уже выполняется задача"})
    threading.Thread(target=task_fetch_openphish, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/upload_txt", methods=["POST"])
def api_upload_txt():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "Файл не найден"})
    f = request.files["file"]
    content = f.read().decode("utf-8")
    threading.Thread(target=task_load_txt, args=(content,), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/start_screenshots", methods=["POST"])
def api_screenshots():
    if state["running"]:
        return jsonify({"ok": False, "error": "Уже выполняется задача"})
    data = request.json or {}
    num_from = int(data.get("from", 1))
    num_to   = int(data.get("to",   9999))
    threading.Thread(target=task_screenshots, args=(num_from, num_to), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/start_upload", methods=["POST"])
def api_upload():
    if state["running"]:
        return jsonify({"ok": False, "error": "Уже выполняется задача"})
    data = request.json or {}
    num_from = int(data.get("from", 1))
    num_to   = int(data.get("to",   9999))
    threading.Thread(target=task_upload, args=(num_from, num_to), daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/start_auto", methods=["POST"])
def api_auto():
    if state["running"]:
        return jsonify({"ok": False, "error": "Уже выполняется задача"})
    threading.Thread(target=task_auto, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    with state_lock:
        state["running"] = False
    log("⏹ Остановлено пользователем", "warn")
    return jsonify({"ok": True})


@app.route("/api/clear_log", methods=["POST"])
def api_clear_log():
    with state_lock:
        state["log"] = []
    return jsonify({"ok": True})


# ════════════════════════════════════════════════════════════════
# ЗАДАЧИ
# ════════════════════════════════════════════════════════════════

def task_fetch_openphish():
    with state_lock:
        state["running"] = True
        state["task"]    = "fetch"

    log("📥 Получаю ссылки с OpenPhish...")
    try:
        r = requests.get("https://openphish.com/feed.txt", timeout=15)
        r.raise_for_status()
        urls = [u.strip() for u in r.text.strip().splitlines() if u.strip()]
        log(f"✅ Получено {len(urls)} ссылок с OpenPhish")
        _save_links(urls, "openphish")
    except Exception as e:
        log(f"❌ OpenPhish: {e} — пробую PhishTank...", "error")
        try:
            r = requests.get(
                "http://data.phishtank.com/data/online-valid.json",
                timeout=20, headers={"User-Agent": "phishtank/test"}
            )
            data = r.json()
            urls = [item["url"] for item in data[:3000]]
            log(f"✅ Получено {len(urls)} ссылок с PhishTank")
            _save_links(urls, "phishtank")
        except Exception as e2:
            log(f"❌ PhishTank: {e2}", "error")

    with state_lock:
        state["running"] = False
        state["task"]    = None


def task_load_txt(content):
    with state_lock:
        state["running"] = True
        state["task"]    = "fetch"

    log("📂 Обрабатываю загруженный файл...")
    urls = []
    for line in content.strip().splitlines():
        line = line.strip()
        m = re.match(r"^(\d+)\.\s+(.+)$", line)
        if m:
            urls.append(m.group(2).strip())
        elif line.startswith("http"):
            urls.append(line)

    log(f"✅ Найдено {len(urls)} ссылок")
    _save_links(urls, "manual")

    with state_lock:
        state["running"] = False
        state["task"]    = None


def _save_links(urls, source="manual"):
    cfg = load_config()
    os.makedirs(cfg["data_dir"], exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(cfg["data_dir"], f"links_{ts}.csv")

    rows = []
    for i, url in enumerate(urls, 1):
        rows.append({
            "title":        f"Site {i}",
            "url":          url,
            "reason":       cfg["default_reason"],
            "object_type":  cfg["default_object_type"],
            "resource_type": cfg["default_resource_type"],
            "violation":    cfg["default_violation"],
            "language":     cfg["default_language"],
            "group":        cfg["default_group"],
            "screenshot":   os.path.join(cfg["screens_dir"], f"{i}.png"),
            "publications": "",
            "subscribers":  "",
            "court_decision": "нет",
            "source":       source,
        })

    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys(), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)

    with state_lock:
        state["links"]    = rows
        state["csv_path"] = csv_path
        state["stats"]["total_links"] = len(rows)

    log(f"💾 CSV сохранён: {csv_path}")


def task_screenshots(num_from=1, num_to=9999):
    with state_lock:
        state["running"] = True
        state["task"]    = "screenshot"
        state["ok"]      = 0
        state["err"]     = 0
        state["skip"]    = 0
        links = state["links"]

    cfg = load_config()
    os.makedirs(cfg["screens_dir"], exist_ok=True)

    jobs = []
    for r in links:
        m = re.search(r"\d+", r["title"])
        if m:
            n = int(m.group())
            if num_from <= n <= num_to:
                jobs.append((n, r["url"]))

    jobs.sort(key=lambda x: x[0])
    total = len(jobs)
    log(f"📸 Скриншоты через Google Safe Browsing: {total} ссылок")

    ok = err = skip = 0

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context(
            viewport={"width": 1366, "height": 768},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            )
        )
        page = context.new_page()

        for i, (num, url) in enumerate(jobs, 1):
            if not state["running"]:
                break

            path = Path(cfg["screens_dir"]) / f"{num}.png"

            if path.exists():
                skip += 1
                set_progress(i, total, ok, err, skip)
                continue

            log(f"[{i}/{total}] Site {num}: {url[:65]}")

            try:
                # Открываем Google Safe Browsing Transparency Report
                encoded = urllib.parse.quote(url, safe="")
                gsb_url = f"https://transparencyreport.google.com/safe-browsing/search?url={encoded}"

                page.goto(gsb_url, wait_until="domcontentloaded", timeout=25000)
                page.wait_for_timeout(3000)

                # Ждём загрузки результата
                try:
                    page.wait_for_selector(
                        "[class*='site-status'], [class*='safe'], "
                        "[class*='unsafe'], [class*='result'], "
                        "mat-card, .site-status",
                        timeout=10000
                    )
                except PWTimeout:
                    pass

                page.wait_for_timeout(1500)
                page.evaluate("window.scrollTo(0, 0)")
                page.wait_for_timeout(300)
                page.screenshot(path=str(path), full_page=False)
                ok += 1
                log(f"  ✅ {num}.png сохранён")

            except Exception as e:
                err += 1
                log(f"  ❌ {e}", "error")
                try:
                    page.screenshot(path=str(path), full_page=False)
                    ok += 1
                except Exception:
                    pass

            set_progress(i, total, ok, err, skip)
            with state_lock:
                state["stats"]["total_screens"] = ok
                state["stats"]["total_errors"]  = err

            time.sleep(0.5)

        browser.close()

    log(f"📸 Скриншоты завершены: OK={ok} SKIP={skip} ERR={err}")
    with state_lock:
        state["running"] = False
        state["task"]    = None


def task_upload(num_from=1, num_to=9999):
    with state_lock:
        state["running"] = True
        state["task"]    = "upload"
        state["ok"]      = 0
        state["err"]     = 0
        links = state["links"]

    cfg = load_config()

    if not os.path.exists(cfg["auth_file"]):
        log(f"❌ Не найден auth.json: {cfg['auth_file']}", "error")
        log("   Запусти save_auth.py для создания файла авторизации", "warn")
        with state_lock:
            state["running"] = False
            state["task"]    = None
        return

    jobs = []
    for r in links:
        m = re.search(r"\d+", r["title"])
        if m:
            n = int(m.group())
            if num_from <= n <= num_to:
                jobs.append(r)

    total = len(jobs)
    ok = err = 0
    log(f"🚀 Загрузка в кибернадзор: {total} ссылок")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=150)
        context = browser.new_context(storage_state=cfg["auth_file"])
        page    = context.new_page()

        page.goto(cfg["knadzor_url"], wait_until="domcontentloaded")
        page.wait_for_timeout(2000)

        for i, row in enumerate(jobs, 1):
            if not state["running"]:
                break

            log(f"[{i}/{total}] {row['title']}: {row['url'][:60]}")

            try:
                _upload_one(page, row, cfg)
                ok += 1
                log(f"  ✅ Загружено в кибернадзор")
            except Exception as e:
                err += 1
                log(f"  ❌ {e}", "error")
                try:
                    page.keyboard.press("Escape")
                    page.wait_for_timeout(500)
                except Exception:
                    pass

            set_progress(i, total, ok, err)
            with state_lock:
                state["stats"]["total_uploaded"] = ok
                state["stats"]["total_errors"]   += 1 if err > 0 else 0

        try:
            context.storage_state(path=cfg["auth_file"])
        except Exception:
            pass
        browser.close()

    log(f"🚀 Загрузка завершена: OK={ok} ERR={err}")
    with state_lock:
        state["running"] = False
        state["task"]    = None


def _upload_one(page, row, cfg):
    def clean(v):
        try:
            if pd.isna(v): return ""
        except Exception:
            pass
        return str(v).strip()

    # Открываем модалку
    page.locator("button", has_text="Добавить ссылку").first.click()
    page.locator("edit-modal .modal-box--small").wait_for(state="visible", timeout=15000)
    page.wait_for_timeout(300)
    modal = page.locator("edit-modal .modal-box--small").first

    # Текстовые поля
    modal.locator('my-input[formcontrolname="title"] input').fill(clean(row["title"]))
    modal.locator('my-input[formcontrolname="url"] input').fill(clean(row["url"]))
    modal.locator('my-textarea[formcontrolname="comment"] textarea').fill(clean(row["reason"]))

    # Судебное решение
    court = clean(row.get("court_decision", "")).lower() in ["1", "true", "да"]
    cb = modal.locator('input[formcontrolname="court_decision"]')
    if court and not cb.is_checked():
        cb.check()

    # Селекты
    def select(fc, text):
        if not text: return
        sel = modal.locator(f'my-select-field[formcontrolname="{fc}"] select').first
        sel.wait_for(state="visible", timeout=8000)
        sel.select_option(label=text)
        page.wait_for_timeout(100)

    select("resource_type", clean(row["object_type"]))
    select("resource",      clean(row["resource_type"]))
    select("offense",       clean(row["violation"]))
    select("language",      clean(row["language"]))

    # Группа
    group = clean(row.get("group", "")).lower()
    if group:
        css_map = {
            "красный":   "attribute--cat-red",
            "оранжевый": "attribute--cat-orange",
        }
        css = css_map.get(group)
        if css:
            try:
                gs   = modal.locator("group-select").first
                attr = gs.locator(f"div.{css}").first
                pan  = attr.locator("xpath=../../..").first
                btn  = pan.locator("div.panel__layout.shrink button").first
                btn.click()
                page.wait_for_timeout(200)
            except Exception:
                pass

    # Скриншот
    num  = re.search(r"\d+", clean(row["title"])).group()
    path = Path(cfg["screens_dir"]) / f"{num}.png"
    if not path.exists():
        raise FileNotFoundError(f"Нет скриншота: {path}")

    fi = modal.locator('input.upload-file[type="file"]').first
    fi.wait_for(state="attached", timeout=8000)
    fi.set_input_files(str(path))
    page.wait_for_timeout(800)

    # Сохраняем
    page.wait_for_timeout(300)
    modal.locator("button.button--primary").first.click()
    try:
        modal.wait_for(state="hidden", timeout=15000)
    except Exception:
        page.wait_for_timeout(2000)


def task_auto():
    log("⚡ АВТО РЕЖИМ запущен")
    task_fetch_openphish()
    time.sleep(2)
    task_screenshots()
    task_upload()
    log("⚡ АВТО РЕЖИМ завершён!")


# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 55)
    print("  🛡️  КИБЕРНАДЗОР — Веб Приложение")
    print("=" * 55)
    print("  Открой в браузере: http://localhost:5000")
    print("  Для сотрудников:   http://[IP этого ПК]:5000")
    print("  Остановить:        Ctrl+C")
    print("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=False)
